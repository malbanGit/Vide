Simple rain simulation for Vectrex computer

If you don't have Vectrex, check out Youtube video: 
http://www.youtube.com/watch?v=MriSTEdnU5U

http://frog.enlight.ru
E-Mail: frog@enlight.ru
