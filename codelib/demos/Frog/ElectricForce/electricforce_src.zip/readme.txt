I strongly recommend to run it only on real hardware (Vectrex).
It runs under emulator (ParaJVE), but looks incorrect.
ParaJVE has problems with code which change DAC while integrating 
(and some other specific features).

I'm sure it works correctly at least on my own Vectrex :-)

If you don't have Vectrex, check out Youtube video: 
http://www.youtube.com/watch?v=lPZPBwaWRuk

Emulators - invaluable tool for development (thank you, Franck Chevassu!) 
but quite bad for everything else.

frog
p.s. credits: svo, tnt23, CC'2015 organizers

http://frog.enlight.ru
E-Mail: frog@enlight.ru
