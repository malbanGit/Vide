I strongly recommend run it only on real hardware (Vectrex).
It runs under emulator (ParaJVE), but looks bad.

If you don't have Vectrex, check out Youtube video: 
https://www.youtube.com/watch?v=vf_fb8G5Rdc

Vectrex rulez!

frog
p.s. credits goes to Svo for ROM emulator card and C-Jeff for music

http://frog.enlight.ru
E-Mail: frog@enlight.ru

===================================================================

VISIT CHAOS CONSTRUCTIONS'2015!

St.Petersburg, Russia
29-30 August 2015
'Moskovskiye vorota' subway station. Moskovsky prospect 107/5, "Skorohod"

contact orgz if you have any questions:
http://chaosconstructions.ru/en

Demos, intros, music, graphics (and some specific) compos
Vintage computers (both soviet and western) exhibition
Seminars

Non-stop (night included)

Entrance fee: 500 roubles

Email: randuev@gmail.com , info@cc.org.ru
Phone: +7 906 250-13-69 (Random)

History of Chaos Constructions (and ENLiGHT): http://cc.org.ru

