#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>
#include <ctype.h>

#include "ayemu.h"

/* LHA5 decoder, defined in lh5dec.c */
extern void lh5_decode(unsigned char *inp,
					 unsigned char *outp,
					 unsigned long original_size,
					 unsigned long packed_size);

/* Read 8-bit integer from file.
 * Return 1 if error occurs
 */
static int read_byte(FILE *fp, int *p)
{
	int c;
	if ((c = getc(fp)) == EOF) {
		perror("libayemu: read_byte()");
		return 1;
	}
	*p = c;
	return 0;
}

/* Read 16-bit integer from file.
 * Return 1 if error occurs
 */
static int read_word16(FILE *fp, int *p)
{
	int c;
	if ((c = getc(fp)) == EOF) {
		perror("libayemu: read_word16()");
		return 1;
	}
	*p = c;

	if ((c = getc(fp)) == EOF) {
		perror("libayemu: read_word16()");
		return 1;
	}
	*p += c << 8;

	return 0;
}

/* read 32-bit integer from file.
 *  Returns 1 if error occurs 
 */
static int read_word32(FILE *fp, int *p)
{
	int c;

	if ((c = getc(fp)) == EOF) {
		perror("libayemu: read_word32()");
		return 1;
	}
	*p = c;

	if ((c = getc(fp)) == EOF) {
		perror("libayemu: read_word32()");
		return 1;
	}
	*p += c << 8;

	if ((c = getc(fp)) == EOF) {
		perror("libayemu: read_word32()");
		return 1;
	}
	*p += c << 16;

	if ((c = getc(fp)) == EOF) {
		perror("libayemu: read_word32()");
		return 1;
	}
	*p += c << 24;

	return 0;
}

/* read_NTstring: reads null-terminated string from file.
 *  Return 1 if error occures.
 */
static int read_NTstring(FILE *fp, char s[])
{
	int i, c;
	for (i = 0 ; i < AYEMU_VTX_NTSTRING_MAX && (c = getc(fp)) != EOF && c ; i++)
		s[i] = c;
	s[i] = '\0';
	if (c == EOF) {
		fprintf(stderr, "libayemu: read_NTstring(): uninspected end of file!\n");
		return 1;
	}
	return 0;
}

/** Open specified .vtx file and read vtx file header
 *
 *  Open specified .vtx file and read vtx file header in struct vtx
 *  Return value: true if success, else false
 */
int ayemu_vtx_open (ayemu_vtx_t *vtx, const char *filename)
{
	char buf[2];
	int error = 0;

	vtx->regdata = NULL;

	if ((vtx->fp = fopen (filename, "rb")) == NULL) {
		fprintf(stderr, "ayemu_vtx_open: Cannot open file %s: %s\n",
			filename, strerror(errno));
		return 0;
	}

	if (fread(buf, 2, 1, vtx->fp) != 1) {
		fprintf(stderr, "ayemu_vtx_open: Can't read from %s: %s\n",
			filename, strerror(errno));
		error = 1;
	}

	buf[0] = tolower(buf[0]);
	buf[1] = tolower(buf[1]);

	if (strncmp(buf, "ay", 2) == 0)
		vtx->hdr.chiptype = AYEMU_AY;
	else if (strncmp (buf, "ym", 2) == 0)
		vtx->hdr.chiptype = AYEMU_YM;
	else {
		fprintf (stderr, "File %s is _not_ VORTEX format!\n"
			 "It not begins with 'AY' or 'YM' string.\n", filename);
		error = 1;
	}

	/* read VTX header info in order format specified */
	if (!error) error = read_byte(vtx->fp, &vtx->hdr.stereo);
	if (!error) error = read_word16(vtx->fp, &vtx->hdr.loop);
	if (!error) error = read_word32(vtx->fp, &vtx->hdr.chipFreq);
	if (!error) error = read_byte(vtx->fp, &vtx->hdr.playerFreq);
	if (!error) error = read_word16(vtx->fp, &vtx->hdr.year);
	if (!error) error = read_word32(vtx->fp, &vtx->hdr.regdata_size);
	if (!error) error = read_NTstring(vtx->fp, vtx->hdr.title);
	if (!error) error = read_NTstring(vtx->fp, vtx->hdr.author);
	if (!error) error = read_NTstring(vtx->fp, vtx->hdr.from);
	if (!error) error = read_NTstring(vtx->fp, vtx->hdr.tracker);
	if (!error) error = read_NTstring (vtx->fp, vtx->hdr.comment);

	if (error) {
		fclose(vtx->fp);
		vtx->fp = NULL;
	}
	return !error;
}

/** Read and encode lha data from .vtx file
 *
 * Return value: pointer to unpacked data or NULL
 * Note: you must call ayemu_vtx_open() first.
 */
char *ayemu_vtx_load_data (ayemu_vtx_t *vtx)
{
	char *packed_data;
	size_t packed_size;
	size_t buf_alloc;
	int c;

	if (vtx->fp == NULL) {
		fprintf(stderr, "ayemu_vtx_load_data: tune file not open yet"
			" (Hint: do you call ayemu_vtx_open first?)\n");
		return NULL;
	}

	packed_size = 0; 
	buf_alloc = 4096;

	packed_data = (char *) malloc (buf_alloc);

	/* read packed AY register data to end of file. */
	while ((c = fgetc (vtx->fp)) != EOF) {
		if (buf_alloc < packed_size) {              
			buf_alloc *= 2;
			packed_data = (char *) realloc (packed_data, buf_alloc);
			if (packed_data == NULL) {
	fprintf (stderr, "ayemu_vtx_load_data: Packed data out of memory!\n");
	fclose (vtx->fp);
	return NULL;
			}
		}
		packed_data[packed_size++] = c;
	}  
	fclose (vtx->fp);

	vtx->fp = NULL;

	if ((vtx->regdata = (char *) malloc (vtx->hdr.regdata_size)) == NULL) {
		fprintf (stderr, "ayemu_vtx_load_data: Can allocate %d bytes"
			 " for unpack register data\n", vtx->hdr.regdata_size);
		free (packed_data);
		return NULL;
	}
	lh5_decode (packed_data, vtx->regdata, vtx->hdr.regdata_size, packed_size);
	free (packed_data);

	vtx->frames = vtx->hdr.regdata_size / 14;

	return vtx->regdata;
}

static void append_string(char *buf, const int sz, const char *str)
{
	if (strlen(buf) + strlen(str) < sz - 1)
		strcat(buf, str);
}

static void append_number(char *buf, const int sz, const int num)
{
	char s[32];
	snprintf(s, sizeof(s), "%d", num);
	return append_string(buf, sz, s);
}

static void append_char(char *buf, const int sz, const char c)
{
	int pos = strlen(buf);
	if (pos < sz - 1)
		buf[pos++] = c;
	buf[pos] = '\0';
}

/** Print formated file name.
 * If fmt string is NULL the following default format string will used:
 * '%a - %t'. The format string have format like printf function.
 * The following format specificator supported:
 * - \b %% the % sign
 * - \b %a author of song
 * - \b %t song title
 * - \b %y year
 * - \b %f song from
 * - \b %T Tracker
 * - \b %C Comment
 * - \b %s stereo type (ABC, BCA, ...)
 * - \b %l 'looped' or 'non-looped'
 * - \b %c chip type: 'AY' or 'YM'
 * - \b %F chip Freq
 * - \b %P player freq
 */
void ayemu_vtx_sprintname (const ayemu_vtx_t *vtx, char *const buf,
				 const int sz, const char *fmt)
{
	static char *stereo_types[] =
		{ "MONO", "ABC", "ACB", "BAC", "BCA", "CAB", "CBA" };

	if (fmt == NULL)
		fmt = "%a - %t";

	buf[0] = '\0';

	while (*fmt != '\0') {
		if (*fmt == '%') {
			switch(*++fmt) {
			case 'a':
	append_string(buf, sz, vtx->hdr.author);
	break;
			case 't':
	append_string(buf, sz, vtx->hdr.title);
	break;
			case 'y':
	append_number(buf, sz, vtx->hdr.year);
	break;
			case 'f':
	append_string(buf, sz, vtx->hdr.from);
	break;
			case 'T':
	append_string(buf, sz, vtx->hdr.tracker);
	break;
			case 'C':
	append_string(buf, sz, vtx->hdr.comment);
	break;
			case 's':
	append_string(buf, sz, stereo_types[vtx->hdr.stereo]);
	break;
			case 'l':
	append_string(buf, sz, (vtx->hdr.loop)? "looped" : "non-looped" );
	break;
			case 'c':
	append_string(buf, sz, (vtx->hdr.chiptype == AYEMU_AY)? "AY" : "YM" );
	break;
			case 'F':
	append_number(buf, sz, vtx->hdr.chipFreq);
	break;
			case 'P':
	append_number(buf, sz, vtx->hdr.playerFreq);
	break;
			default:
	append_char(buf, sz, *fmt);
			}
			fmt++;
		} else {
			append_char(buf, sz, *fmt++);
		}
	}
}

/** Get specified data frame by number.
 *
 */
void ayemu_vtx_getframe(const ayemu_vtx_t *vtx, size_t frame_n,
						 unsigned char *regs)
{
	int n;

	if (frame_n >= vtx->frames)
		return;

	// calculate begin of data
	char *p = vtx->regdata + frame_n;

	// step is data size / 14
	for(n = 0 ; n < 14 ; n++) {
			regs[n] = *p;
			p += vtx->frames;
	}
}

/** Free all of allocaded resource for this file.
 *
 * Free the unpacket register data if is and close file.
 */
void ayemu_vtx_free (ayemu_vtx_t *vtx)
{
	if (vtx->fp) {
		fclose(vtx->fp);
		vtx->fp = NULL;
	}

	if (vtx->regdata) {
		free(vtx->regdata);
		vtx->regdata = NULL;
	}
}
